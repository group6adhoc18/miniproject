import time

def writeState(states):
    template = 'Light outsite: \t{}\nSmart phone detection: \t{}\nDoor current action: \t{}\nDoor state: \t{}\nLight relays: \t{}\n'
    states[0] = 'bright' if states[0] else 'dark'
    states[2] = 'open' if states[2] else 'closed'

    f = open('controllerState.txt', 'w')
    f.write(template.format(*states))
    f.close()


case_nothing = [False, False, False, False, False]
case_bright = [True, False, False, False, False]
case_door = [False, False, True, True, True]
case_smartphone = [False, True, False, False, True]


def videoStateSequence():

    sequence = [
        [case_nothing, 8],      # 0:02
        [case_door, 7],         # 0:10
        [case_smartphone, 27],  # 0:17
        [case_bright, 20],      # 0:44
        [case_smartphone, 47],  # 1:05
        [case_nothing, 0],   # 1:53

    ]

    elapsed = 0
    for event in sequence:
        writeState(event[0].copy())
        time.sleep(event[1])
        elapsed += event[1]
        print('time:', elapsed)

videoStateSequence()
