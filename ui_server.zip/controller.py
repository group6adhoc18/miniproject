import asyncio

from enum import Enum

class LIGHTSENSOR_RESOURCE(Enum):
    DAYLIGHT = "/lightsensor/daylight",
    THRESHOLD_MIN = "lightsensor/threshold/min",
    THRESHOLD_MAX = "lightsensor/threshold/max",
    UNDEFINED = "UNDEFINED"


lightsensorValues = {}
lightsensorValues[(LIGHTSENSOR_RESOURCE.THRESHOLD_MIN.value)[0]] = '111'
lightsensorValues[(LIGHTSENSOR_RESOURCE.THRESHOLD_MAX.value)[0]] = '222'


async def get_lightsensor_resource(res_uri):
    return lightsensorValues[res_uri.value[0]]


async def set_lightsensor_threshold(res_uri, value):
    lightsensorValues[res_uri.value[0]] = value
